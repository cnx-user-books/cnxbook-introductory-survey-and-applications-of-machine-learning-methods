function X_poly = PolyFeature(X1, X2, degree)
% This function returns polynomial features for every traning example upto
% a given degree. It also adds the constant 1's as the first column to
% include the bias term.
X_poly = ones(size(X1(:,1)));
for i = 1 : degree
    for j = 0 : i
        X_poly(:,end+1) = (X1.^(i-j)).*(X2.^j);
    end
end

end
        
