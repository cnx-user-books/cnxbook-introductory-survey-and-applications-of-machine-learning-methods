%% Generating the Training and Test Data Sets.

% The points are generated uniformly in a square with side 10 units.
clear; clf;
clc;
load('training_data.mat');
% Determing the label of Training Examples
Y = ones(size(X,1),1);
ind = find(X(:,1) >= 0 & X(:,1) <= 40 & X(:,2) < (6+ (X(:,1)-5).^4).^(1/3));
Y(ind,:) = 0;


%% Computing the Cost and Gradient of Logistic Regression

% Include polynomial features upto a specified degree
degree = 3;
[m,n] = size(X);
X = PolyFeature(X(:,1), X(:,2), degree);
X_cv = X(3*m/5 + 1 : 4*m/5, :); Y_cv = Y(3*m/5 + 1 : 4*m/5, :);
X_test = X(4*m/5 + 1 : m, :); Y_test = Y(4*m/5 + 1 : m, :);
X = X(1 : 3*m/5 , :); Y = Y(1 : 3*m/5 , :);

% Initialize fitting parameters
initial_theta = zeros(size(X,2), 1);

% Compute and display initial cost and gradient for regularized logistic
% regression
[cost, grad] = costFunction(initial_theta, X, Y);


%% Optimizing over the entire parameter space using fminunc

options = optimset('GradObj', 'on', 'MaxIter', 400);
% Optimize
[theta, J, exit_flag] = ...
            fminunc(@(t)(costFunction(t, X, Y)), initial_theta, options);

% Printing the optimal values of parameters
fprintf('Theta : \n');
fprintf('%f \n',theta);

% Plotting the Decision Boundary on Cross-Validation Set
plotDecisionBoundary(theta, X_cv, Y_cv, degree);

% Compute accuracy on our cross-validation set
p = predict(theta, X_cv);
fprintf('\n Cross-Validation Set Accuracy: %f\n', mean(double(p == Y_cv)) * 100);

% Compute accuracy on our test set
p = predict(theta, X_test);
fprintf('\n Test Set Accuracy: %f\n', mean(double(p == Y_test)) * 100);

%% Plotting The Actual Decision Boundary
X1 = 0:.1:10;
Y1 = (6+ (X1-5).^4).^(1/3);
% figure(1);
plot(X1,Y1,'r');
axis([0 10 0 10]);

        
